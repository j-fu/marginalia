#include <stdio.h>
#include <string.h>
#include "infinitecycle.h"
int main (int argc, char *argv[])
{
  int test_mode;
  test_mode=0;
  if ( argc>1 && (strcmp(argv[1],"-test")==0))
    test_mode=1;

  int answer;
  answer=infcyc(0);
  printf("Hello world, the answer is %d!\n",answer);

  if (test_mode && answer!=42)
    {
      printf("broken universe\n");
      return 1;
    }
	
  return 0;
}
