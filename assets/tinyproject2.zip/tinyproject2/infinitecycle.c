#include "infinitecycle.h"
int infcyc(int start)
{	    
  int result;
  result=start;
  for (;result<42;result++);
  return result;
}
