# Demo project for cmake

The explanation is found 
[here](http://www.wias-berlin.de/people/fuhrmann/2014-10-30-cmake.html)
