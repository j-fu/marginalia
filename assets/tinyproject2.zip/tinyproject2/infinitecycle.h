/* well, it is finite, but we don't want to break the API*/
int infcyc(int start); /* call infinite cycle and return result*/

