using Pkg
Pkg.activate(joinpath(@__DIR__, ".."))
Pkg.instantiate()
