"""
Placeholder for a short summary about {PKGNAME}.
"""
module {PKGNAME}

greet() = "Hello from  {PKGNAME}"

end # module
